﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto1
{
    class Carro
    {
        public string placa;
        public string marca;
        public string modelo;
        public string chassi;
        public string cor;
        public int ano;

        public void Registrar()
        {
        }

        public void Editar()
        {
        }
    }
}
