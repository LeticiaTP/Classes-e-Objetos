﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2
{
    class Turma
    {
       public int numeroDaTurma;
       public int numeroDaSala;
       public string disciplina;
       public string bloco;
       public string disponivel;

    }
}
